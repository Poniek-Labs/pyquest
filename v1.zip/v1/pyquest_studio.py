from __future__ import annotations

import ast
import builtins
import json
import keyword
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal, Slot, QStringListModel
from PySide6.QtGui import (
    QAction,
    QBrush,
    QColor,
    QFont,
    QFontMetrics,
    QImage,
    QKeySequence,
    QLinearGradient,
    QPainter,
    QPen,
    QTextCharFormat,
    QTextCursor,
    QSyntaxHighlighter,
)
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QCompleter,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMainWindow,
    QPlainTextEdit,
    QPushButton,
    QSizePolicy,
    QSplitter,
    QStatusBar,
    QTabWidget,
    QTextEdit,
    QToolBar,
    QVBoxLayout,
    QWidget,
)
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineSettings
from PySide6.QtWebEngineWidgets import QWebEngineView

from syntax_config import SYNTAX_SCHEMES

APP_NAME = "PyQuest Studio"
APP_VERSION = "0.2.0"
APP_DIR = Path(__file__).resolve().parent
LESSONS_DIR = APP_DIR / "lessons"
DATA_DIR = APP_DIR / ".pyquest_studio"
PROGRESS_PATH = DATA_DIR / "progress.json"

DEFAULT_FEATURES = {
    "syntax_highlighting": True,
    "autocomplete": False,
    "error_hints": False,
    "debugger": False,
    "file_system_access": False,
    "multi_file_support": False,
}

FREE_MODE_FEATURES = {name: True for name in DEFAULT_FEATURES}


@dataclass
class ValidationResult:
    success: bool
    messages: list[str] = field(default_factory=list)
    unlocked_features: list[str] = field(default_factory=list)
    next_lesson: str | None = None
    xp_awarded: int = 0
    lesson_completed_now: bool = False

    def as_dict(self) -> dict[str, object]:
        return {
            "success": self.success,
            "messages": self.messages,
            "unlocked_features": self.unlocked_features,
            "next_lesson": self.next_lesson,
            "xp_awarded": self.xp_awarded,
            "lesson_completed_now": self.lesson_completed_now,
        }


@dataclass
class ExecutionResult:
    stdout: str
    stderr: str
    exit_code: int
    timed_out: bool = False

    def as_dict(self) -> dict[str, object]:
        return {
            "stdout": self.stdout,
            "stderr": self.stderr,
            "exit_code": self.exit_code,
            "timed_out": self.timed_out,
        }


@dataclass
class LessonDefinition:
    lesson_id: str
    title: str
    folder: Path
    html_path: Path
    validation_rules: dict[str, object]
    xp_reward: int = 0
    unlocks: list[str] = field(default_factory=list)
    next_lesson: str | None = None
    starter_code: str = ""
    summary: str = ""
    why_it_matters: str = ""
    tip: str = ""
    steps: list[str] = field(default_factory=list)
    checklist: list[str] = field(default_factory=list)
    common_mistakes: list[str] = field(default_factory=list)
    example_code: str = ""
    badge_title: str = ""

    @classmethod
    def from_folder(cls, folder: Path) -> "LessonDefinition | None":
        html_path = folder / "index.html"
        validation_path = folder / "validation.json"
        if not html_path.exists():
            return None

        rules: dict[str, object] = {}
        if validation_path.exists():
            rules = json.loads(validation_path.read_text(encoding="utf-8"))

        title = str(rules.get("title") or folder.name.replace("_", " ").title())
        return cls(
            lesson_id=folder.name,
            title=title,
            folder=folder,
            html_path=html_path,
            validation_rules=rules,
            xp_reward=int(rules.get("xp_reward", 0)),
            unlocks=list(rules.get("unlocks", [])),
            next_lesson=rules.get("next_lesson"),
            starter_code=str(rules.get("starter_code", "")),
            summary=str(rules.get("summary", "")),
            why_it_matters=str(rules.get("why_it_matters", "")),
            tip=str(rules.get("tip", "")),
            steps=list(rules.get("steps", [])),
            checklist=list(rules.get("checklist", [])),
            common_mistakes=list(rules.get("common_mistakes", [])),
            example_code=str(rules.get("example_code", "")),
            badge_title=str(rules.get("badge_title", title)),
        )


class ProgressStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.data = self._load()

    def _load(self) -> dict[str, object]:
        if self.path.exists():
            try:
                return json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                pass
        data = {
            "mode": "learning",
            "current_lesson": "variables_intro",
            "completed_lessons": [],
            "unlocked_features": dict(DEFAULT_FEATURES),
            "xp": 0,
            "level": 1,
        }
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return data

    def save(self) -> None:
        self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")

    def current_mode(self) -> str:
        return str(self.data.get("mode", "learning"))

    def set_mode(self, mode: str) -> None:
        self.data["mode"] = mode
        self.save()

    def current_lesson(self) -> str:
        return str(self.data.get("current_lesson", "variables_intro"))

    def set_current_lesson(self, lesson_id: str) -> None:
        self.data["current_lesson"] = lesson_id
        self.save()

    def completed_lessons(self) -> set[str]:
        return set(self.data.get("completed_lessons", []))

    def mark_completed(self, lesson_id: str) -> None:
        completed = self.completed_lessons()
        completed.add(lesson_id)
        self.data["completed_lessons"] = sorted(completed)
        self.save()

    def unlocked_features(self) -> dict[str, bool]:
        features = dict(DEFAULT_FEATURES)
        features.update(self.data.get("unlocked_features", {}))
        features["syntax_highlighting"] = True
        return features

    def unlock_features(self, features: list[str]) -> list[str]:
        unlocked = self.unlocked_features()
        changed: list[str] = []
        for feature in features:
            if feature in unlocked and not unlocked[feature]:
                unlocked[feature] = True
                changed.append(feature)
        self.data["unlocked_features"] = unlocked
        if changed:
            self.save()
        return changed

    def add_xp(self, xp: int) -> int:
        total = int(self.data.get("xp", 0)) + xp
        self.data["xp"] = total
        self.data["level"] = max(1, total // 100 + 1)
        self.save()
        return total

    def xp(self) -> int:
        return int(self.data.get("xp", 0))

    def level(self) -> int:
        return int(self.data.get("level", 1))

    def reset(self, first_lesson_id: str) -> None:
        self.data = {
            "mode": "learning",
            "current_lesson": first_lesson_id,
            "completed_lessons": [],
            "unlocked_features": dict(DEFAULT_FEATURES),
            "xp": 0,
            "level": 1,
        }
        self.save()


class LessonManager:
    def __init__(self, lessons_dir: Path) -> None:
        self.lessons_dir = lessons_dir
        self.lessons = self._load_lessons()

    def _load_lessons(self) -> dict[str, LessonDefinition]:
        lessons: dict[str, LessonDefinition] = {}
        if not self.lessons_dir.exists():
            return lessons
        for folder in sorted(path for path in self.lessons_dir.iterdir() if path.is_dir()):
            lesson = LessonDefinition.from_folder(folder)
            if lesson is not None:
                lessons[lesson.lesson_id] = lesson
        return lessons

    def get(self, lesson_id: str) -> LessonDefinition | None:
        return self.lessons.get(lesson_id)

    def first_lesson_id(self) -> str | None:
        return next(iter(self.lessons), None)


class PythonRunner:
    BLOCKED_IMPORTS = {"os", "subprocess", "pathlib", "shutil", "socket", "ctypes", "multiprocessing"}

    def execute(self, code: str, timeout_seconds: int = 5, stdin_text: str = "") -> ExecutionResult:
        blocked_message = self._blocked_import_message(code)
        if blocked_message is not None:
            return ExecutionResult(stdout="", stderr=blocked_message, exit_code=1)

        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as handle:
            temp_path = Path(handle.name)
            handle.write(code)

        try:
            completed = subprocess.run(
                [sys.executable, "-I", str(temp_path)],
                capture_output=True,
                text=True,
                timeout=timeout_seconds,
                cwd=str(APP_DIR),
                input=stdin_text,
            )
            return ExecutionResult(
                stdout=completed.stdout,
                stderr=completed.stderr,
                exit_code=completed.returncode,
            )
        except subprocess.TimeoutExpired as error:
            return ExecutionResult(
                stdout=error.stdout or "",
                stderr=(error.stderr or "") + "\nExecution timed out.",
                exit_code=1,
                timed_out=True,
            )
        finally:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass

    def _blocked_import_message(self, code: str) -> str | None:
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return None

        blocked: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    if top in self.BLOCKED_IMPORTS:
                        blocked.add(top)
            elif isinstance(node, ast.ImportFrom) and node.module:
                top = node.module.split(".")[0]
                if top in self.BLOCKED_IMPORTS:
                    blocked.add(top)

        if not blocked:
            return None
        names = ", ".join(sorted(blocked))
        return f"Blocked import in learning mode: {names}"


class LessonValidator:
    NODE_ALIASES = {
        "print": ast.Call,
        "for": ast.For,
        "while": ast.While,
        "if": ast.If,
        "function": ast.FunctionDef,
        "class": ast.ClassDef,
    }

    def __init__(self, runner: PythonRunner) -> None:
        self.runner = runner

    def validate(self, lesson: LessonDefinition, code: str) -> ValidationResult:
        rules = lesson.validation_rules
        messages: list[str] = []
        unlocked_features = list(lesson.unlocks)

        try:
            tree = ast.parse(code)
        except SyntaxError as error:
            return ValidationResult(success=False, messages=[f"Syntax error: {error.msg} on line {error.lineno}."])

        assigned_names = {
            node.id
            for node in ast.walk(tree)
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store)
        }

        for required_name in rules.get("required_variables", []):
            if required_name not in assigned_names:
                messages.append(f"Create a variable named `{required_name}`.")

        for fragment in rules.get("required_source_fragments", []):
            if fragment not in code:
                messages.append(f"Include `{fragment}` in your code.")

        for node_name in rules.get("must_use", []):
            if not self._uses_construct(tree, node_name):
                messages.append(f"Use `{node_name}` somewhere in your solution.")

        execution = self.runner.execute(code, stdin_text=str(rules.get("stdin_text", "")))
        required_output = str(rules.get("required_output", "")).strip()
        if required_output and required_output not in execution.stdout:
            messages.append(f'Expected output to include "{required_output}".')

        if rules.get("must_run_without_errors", False) and execution.exit_code != 0:
            details = execution.stderr.strip() or "The code finished with an error."
            messages.append(details)

        success = not messages
        return ValidationResult(
            success=success,
            messages=["Lesson complete. Nice work."] if success else messages,
            unlocked_features=unlocked_features if success else [],
            next_lesson=lesson.next_lesson if success else None,
            xp_awarded=lesson.xp_reward if success else 0,
        )

    def _uses_construct(self, tree: ast.AST, name: str) -> bool:
        if name == "print":
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "print":
                    return True
            return False

        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == name:
                return True

        node_type = self.NODE_ALIASES.get(name)
        return bool(node_type and any(isinstance(node, node_type) for node in ast.walk(tree)))


class PythonHighlighter(QSyntaxHighlighter):
    def __init__(self, document, enabled: bool = False) -> None:
        super().__init__(document)
        self.enabled = enabled
        self._multiline_rules = [
            ("'''", "'''", 1),
            ('"""', '"""', 2),
        ]

        self.keyword_format = self._make_format("#7dd3fc", bold=True)
        self.builtin_format = self._make_format("#f59e0b", bold=True)
        self.string_format = self._make_format("#86efac")
        self.comment_format = self._make_format("#94a3b8", italic=True)
        self.number_format = self._make_format("#c084fc")
        self.decorator_format = self._make_format("#fb7185")
        self.definition_format = self._make_format("#38bdf8", bold=True)
        self.operator_format = self._make_format("#fda4af")
        self.special_name_format = self._make_format("#fde68a", bold=True)
        self.rule_specs = self._build_rule_specs()

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled
        self.rehighlight()

    def _make_format(self, color: str, bold: bool = False, italic: bool = False) -> QTextCharFormat:
        text_format = QTextCharFormat()
        text_format.setForeground(QColor(color))
        if bold:
            text_format.setFontWeight(QFont.Bold)
        if italic:
            text_format.setFontItalic(True)
        return text_format

    def _build_rule_specs(self) -> list[tuple[re.Pattern[str], QTextCharFormat, str | None]]:
        keywords = sorted(set(keyword.kwlist) | {"match", "case"})
        builtins_list = sorted(
            name for name in dir(builtins)
            if not name.startswith("_") and isinstance(getattr(builtins, name), object)
        )
        operators = [
            r"\*\*",
            r"//",
            r"==",
            r"!=",
            r"<=",
            r">=",
            r"\+=",
            r"-=",
            r"\*=",
            r"/=",
            r"%=",
            r"->",
            r"\+",
            r"-",
            r"\*",
            r"/",
            r"%",
            r"<",
            r">",
            r"=",
        ]
        return [
            (re.compile(r"#[^\n]*"), self.comment_format, None),
            (re.compile(r"(?<![\w])@[A-Za-z_][A-Za-z0-9_]*"), self.decorator_format, None),
            (re.compile(r"\b(class)\s+([A-Za-z_][A-Za-z0-9_]*)"), self.keyword_format, "definition"),
            (re.compile(r"\b(def)\s+([A-Za-z_][A-Za-z0-9_]*)"), self.keyword_format, "definition"),
            (re.compile(r"\b(" + "|".join(re.escape(word) for word in keywords) + r")\b"), self.keyword_format, None),
            (re.compile(r"\b(" + "|".join(re.escape(word) for word in builtins_list) + r")\b"), self.builtin_format, None),
            (re.compile(r"\b(self|cls|True|False|None)\b"), self.special_name_format, None),
            (re.compile(r"\b\d+(?:_\d+)*(?:\.\d+(?:_\d+)*)?\b"), self.number_format, None),
            (re.compile("|".join(operators)), self.operator_format, None),
            (re.compile(r"'(?:[^'\\]|\\.)*'"), self.string_format, None),
            (re.compile(r'"(?:[^"\\]|\\.)*"'), self.string_format, None),
        ]

    def highlightBlock(self, text: str) -> None:
        if not self.enabled:
            return

        self.setCurrentBlockState(0)

        for pattern, text_format, special_handler in self.rule_specs:
            for match in pattern.finditer(text):
                if special_handler == "definition":
                    keyword_start, keyword_end = match.span(1)
                    name_start, name_end = match.span(2)
                    self.setFormat(keyword_start, keyword_end - keyword_start, self.keyword_format)
                    self.setFormat(name_start, name_end - name_start, self.definition_format)
                else:
                    start, end = match.span()
                    self.setFormat(start, end - start, text_format)

        for start_delimiter, end_delimiter, state in self._multiline_rules:
            if self._apply_multiline_string(text, start_delimiter, end_delimiter, state):
                break

    def _apply_multiline_string(self, text: str, start_delimiter: str, end_delimiter: str, state: int) -> bool:
        start = 0
        add = 0
        if self.previousBlockState() != state:
            start = text.find(start_delimiter)
            add = len(start_delimiter)

        while start >= 0:
            end = text.find(end_delimiter, start + add)
            if end >= 0:
                length = end - start + len(end_delimiter)
                self.setCurrentBlockState(0)
            else:
                self.setCurrentBlockState(state)
                length = len(text) - start
            self.setFormat(start, length, self.string_format)
            start = text.find(start_delimiter, start + length)

        if self.currentBlockState() == state:
            return True
        return False


class LineNumberArea(QWidget):
    def __init__(self, editor: "CodeEditor") -> None:
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        from PySide6.QtCore import QSize

        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event) -> None:
        self.editor.line_number_area_paint_event(event)


class CodeEditor(QPlainTextEdit):
    def __init__(self) -> None:
        super().__init__()
        self.setFont(QFont("Consolas", 12))
        self.setTabStopDistance(QFontMetrics(self.font()).horizontalAdvance(" ") * 4)
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setStyleSheet(
            "QPlainTextEdit {"
            " background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0f172a, stop:1 #172554);"
            " color: #e5eefb;"
            " selection-background-color: #f97316;"
            " border: 1px solid #38bdf8;"
            " border-radius: 12px;"
            " padding: 8px;"
            "}"
        )
        self.line_number_area = LineNumberArea(self)
        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.cursorPositionChanged.connect(self.highlight_current_line)
        self.update_line_number_area_width(0)
        self.highlight_current_line()
        self.highlighter = PythonHighlighter(self.document())
        self.completer: QCompleter | None = None
        self.autocomplete_enabled = False

    def set_syntax_enabled(self, enabled: bool) -> None:
        self.highlighter.set_enabled(enabled)

    def set_autocomplete_enabled(self, enabled: bool) -> None:
        self.autocomplete_enabled = enabled
        if not enabled:
            if self.completer is not None:
                self.completer.popup().hide()
            return
        if self.completer is None:
            words = sorted(set(SYNTAX_SCHEMES[".py"]["keywords"]) | {"print", "input", "len", "range", "str", "int", "float", "list"})
            self.completer = QCompleter()
            self.completer.setModel(QStringListModel(words, self.completer))
            self.completer.setCaseSensitivity(Qt.CaseInsensitive)
            self.completer.setWidget(self)
            self.completer.activated.connect(self.insert_completion)

    def insert_completion(self, completion: str) -> None:
        cursor = self.textCursor()
        extra = len(completion) - len(self.text_under_cursor())
        cursor.movePosition(QTextCursor.Left)
        cursor.movePosition(QTextCursor.EndOfWord)
        cursor.insertText(completion[-extra:] if extra > 0 else "")
        self.setTextCursor(cursor)

    def text_under_cursor(self) -> str:
        cursor = self.textCursor()
        cursor.select(QTextCursor.WordUnderCursor)
        return cursor.selectedText()

    def keyPressEvent(self, event) -> None:
        if self.completer is not None and self.completer.popup().isVisible():
            if event.key() in (Qt.Key_Enter, Qt.Key_Return, Qt.Key_Escape, Qt.Key_Tab, Qt.Key_Backtab):
                event.ignore()
                return

        super().keyPressEvent(event)

        if not self.autocomplete_enabled or self.completer is None:
            return

        prefix = self.text_under_cursor()
        if len(prefix) < 2:
            self.completer.popup().hide()
            return

        self.completer.setCompletionPrefix(prefix)
        popup = self.completer.popup()
        popup.setCurrentIndex(self.completer.completionModel().index(0, 0))
        rect = self.cursorRect()
        rect.setWidth(popup.sizeHintForColumn(0) + popup.verticalScrollBar().sizeHint().width())
        self.completer.complete(rect)

    def line_number_area_width(self) -> int:
        digits = len(str(max(1, self.blockCount())))
        return 14 + self.fontMetrics().horizontalAdvance("9") * digits

    def update_line_number_area_width(self, _: int) -> None:
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def update_line_number_area(self, rect, dy: int) -> None:
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(0, rect.y(), self.line_number_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width(0)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        contents_rect = self.contentsRect()
        self.line_number_area.setGeometry(
            contents_rect.left(),
            contents_rect.top(),
            self.line_number_area_width(),
            contents_rect.height(),
        )

    def line_number_area_paint_event(self, event) -> None:
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor("#10203d"))

        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(block).height())

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)
                painter.setPen(QColor("#7dd3fc"))
                painter.drawText(0, top, self.line_number_area.width() - 6, self.fontMetrics().height(), Qt.AlignRight, number)
            block = block.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(block).height())
            block_number += 1

    def highlight_current_line(self) -> None:
        if self.isReadOnly():
            return
        extra_selections = []
        selection = QTextEdit.ExtraSelection()
        selection.format.setBackground(QColor("#1e3a5f"))
        selection.format.setProperty(QTextCharFormat.FullWidthSelection, True)
        selection.cursor = self.textCursor()
        selection.cursor.clearSelection()
        extra_selections.append(selection)
        self.setExtraSelections(extra_selections)


class TutorialBridge(QObject):
    validationReady = Signal(str)
    lessonChanged = Signal(str)

    def __init__(self, window: "LearningIDE") -> None:
        super().__init__()
        self.window = window

    @Slot(result="QVariant")
    def getUserCode(self) -> dict[str, object]:
        return {"code": self.window.current_code()}

    @Slot(result="QVariant")
    def getCurrentLessonInfo(self) -> dict[str, object]:
        return self.window.current_lesson_info()

    @Slot(result="QVariant")
    def runUserCode(self) -> dict[str, object]:
        return self.window.run_code().as_dict()

    @Slot(result="QVariant")
    def validateCode(self) -> dict[str, object]:
        return self.window.validate_current_lesson().as_dict()

    @Slot(str, result="QVariant")
    def unlockFeature(self, feature_name: str) -> dict[str, object]:
        changed = self.window.unlock_features([feature_name])
        return {"unlocked": changed}

    @Slot(result="QVariant")
    def goToNextLesson(self) -> dict[str, object]:
        moved = self.window.go_to_next_lesson()
        return {"moved": moved, "currentLesson": self.window.current_lesson_id}


class LearningIDE(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.progress = ProgressStore(PROGRESS_PATH)
        self.lesson_manager = LessonManager(LESSONS_DIR)
        self.runner = PythonRunner()
        self.validator = LessonValidator(self.runner)
        self.current_lesson_id = self.progress.current_lesson()
        if self.lesson_manager.get(self.current_lesson_id) is None:
            fallback = self.lesson_manager.first_lesson_id()
            self.current_lesson_id = fallback or ""

        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1500, 920)
        self._build_ui()
        self._load_initial_lesson()
        self._apply_feature_state()

    def _build_ui(self) -> None:
        self.setStyleSheet(
            "QMainWindow { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0f172a, stop:0.45 #1d4ed8, stop:1 #0f766e); color: #eff6ff; }"
            "QWidget { color: #eff6ff; }"
            "QFrame { background: rgba(8, 15, 33, 0.34); border-radius: 16px; }"
            "QToolBar { background: rgba(15, 23, 42, 0.88); border: 1px solid rgba(125, 211, 252, 0.35); border-radius: 14px; spacing: 8px; padding: 8px; }"
            "QToolButton { background: rgba(59, 130, 246, 0.22); border: 1px solid rgba(125, 211, 252, 0.25); border-radius: 10px; padding: 8px 12px; color: #f8fafc; }"
            "QToolButton:hover { background: rgba(249, 115, 22, 0.3); }"
            "QLabel { color: #e0f2fe; background: transparent; }"
            "QComboBox { background: rgba(15, 23, 42, 0.92); border: 1px solid #38bdf8; border-radius: 8px; padding: 4px 10px; color: #f8fafc; }"
            "QTabWidget::pane { border: 1px solid rgba(56, 189, 248, 0.35); background: rgba(15, 23, 42, 0.74); border-radius: 14px; }"
            "QTabBar::tab { background: rgba(15, 23, 42, 0.72); color: #cbd5e1; padding: 8px 14px; border-top-left-radius: 10px; border-top-right-radius: 10px; }"
            "QTabBar::tab:selected { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #f97316, stop:1 #06b6d4); color: #ffffff; }"
            "QSplitter::handle { background: rgba(125, 211, 252, 0.28); }"
            "QStatusBar { background: rgba(15, 23, 42, 0.9); color: #e0f2fe; border-top: 1px solid rgba(125, 211, 252, 0.25); }"
        )

        toolbar = QToolBar("Main")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        self.run_action = QAction("Run", self)
        self.run_action.setShortcut(QKeySequence("Ctrl+R"))
        self.run_action.triggered.connect(self.run_code)
        toolbar.addAction(self.run_action)

        self.validate_action = QAction("Validate Lesson", self)
        self.validate_action.triggered.connect(self.validate_current_lesson)
        toolbar.addAction(self.validate_action)

        self.next_lesson_action = QAction("Next Lesson", self)
        self.next_lesson_action.triggered.connect(self.go_to_next_lesson)
        toolbar.addAction(self.next_lesson_action)

        self.new_tab_action = QAction("New File", self)
        self.new_tab_action.setShortcut(QKeySequence("Ctrl+N"))
        self.new_tab_action.triggered.connect(self.new_editor_tab)
        toolbar.addAction(self.new_tab_action)

        self.open_action = QAction("Open", self)
        self.open_action.setShortcut(QKeySequence("Ctrl+O"))
        self.open_action.triggered.connect(self.open_file)
        toolbar.addAction(self.open_action)

        self.save_action = QAction("Save", self)
        self.save_action.setShortcut(QKeySequence("Ctrl+S"))
        self.save_action.triggered.connect(self.save_file)
        toolbar.addAction(self.save_action)

        self.reset_progress_action = QAction("Reset Progress", self)
        self.reset_progress_action.triggered.connect(self.reset_progress)
        toolbar.addAction(self.reset_progress_action)

        toolbar.addSeparator()
        toolbar.addWidget(QLabel("Mode"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["learning", "free"])
        self.mode_combo.setCurrentText(self.progress.current_mode())
        self.mode_combo.currentTextChanged.connect(self.change_mode)
        toolbar.addWidget(self.mode_combo)

        toolbar.addSeparator()
        self.lesson_label = QLabel("Lesson: -")
        toolbar.addWidget(self.lesson_label)

        toolbar.addSeparator()
        self.progress_label = QLabel("")
        toolbar.addWidget(self.progress_label)

        container = QWidget()
        self.setCentralWidget(container)
        root_layout = QVBoxLayout(container)
        root_layout.setContentsMargins(10, 10, 10, 10)

        horizontal_split = QSplitter(Qt.Horizontal)
        right_split = QSplitter(Qt.Vertical)
        self.main_splitter = horizontal_split
        self.right_splitter = right_split
        horizontal_split.addWidget(self._build_tutorial_panel())
        self._build_editor_panel()
        right_split.addWidget(self.editor_shell)
        right_split.addWidget(self._build_console_panel())
        right_split.setStretchFactor(0, 3)
        right_split.setStretchFactor(1, 2)
        horizontal_split.addWidget(right_split)
        horizontal_split.setStretchFactor(0, 4)
        horizontal_split.setStretchFactor(1, 3)
        root_layout.addWidget(horizontal_split)

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Learning mode is ready.")
        QTimer.singleShot(0, self._set_initial_splitter_sizes)

    def _build_tutorial_panel(self) -> QWidget:
        frame = QFrame()
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(0, 0, 8, 0)

        header = QLabel("Tutorial")
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #fef3c7;")
        layout.addWidget(header)

        self.lesson_browser = QWebEngineView()
        self.lesson_browser.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.lesson_profile = QWebEngineProfile("cobz_lessons", self.lesson_browser)
        self.lesson_profile.setPersistentCookiesPolicy(QWebEngineProfile.NoPersistentCookies)
        self.lesson_page = QWebEnginePage(self.lesson_profile, self.lesson_browser)
        self.lesson_browser.setPage(self.lesson_page)
        settings = self.lesson_browser.settings()
        settings.setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
        settings.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, False)

        self.web_channel = QWebChannel(self.lesson_page)
        self.bridge = TutorialBridge(self)
        self.web_channel.registerObject("ideBridge", self.bridge)
        self.lesson_page.setWebChannel(self.web_channel)

        layout.addWidget(self.lesson_browser)
        return frame

    def _build_editor_panel(self) -> QWidget:
        self.editor_shell = QFrame()
        layout = QVBoxLayout(self.editor_shell)
        layout.setContentsMargins(8, 0, 0, 0)

        header_row = QHBoxLayout()
        editor_label = QLabel("Code Editor")
        editor_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #bfdbfe;")
        header_row.addWidget(editor_label)

        self.hint_label = QLabel("")
        self.hint_label.setStyleSheet("color: #fca5a5;")
        header_row.addWidget(self.hint_label, alignment=Qt.AlignRight)
        layout.addLayout(header_row)

        self.editor_tabs = QTabWidget()
        self.editor_tabs.setTabsClosable(True)
        self.editor_tabs.tabCloseRequested.connect(self.close_editor_tab)
        self.editor_tabs.currentChanged.connect(self._refresh_hint_state)
        layout.addWidget(self.editor_tabs)

        self.new_editor_tab()
        return self.editor_shell

    def _build_console_panel(self) -> QWidget:
        frame = QFrame()
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(8, 8, 0, 0)

        header = QLabel("Output")
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #a7f3d0;")
        layout.addWidget(header)

        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Consolas", 11))
        self.console.setStyleSheet(
            "QTextEdit {"
            " background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0b1120, stop:1 #1f2937);"
            " color: #e5f9ff;"
            " border: 1px solid #22d3ee;"
            " border-radius: 12px;"
            " padding: 8px;"
            "}"
        )
        layout.addWidget(self.console)
        return frame

    def current_editor(self) -> CodeEditor:
        editor = self.editor_tabs.currentWidget()
        if not isinstance(editor, CodeEditor):
            raise RuntimeError("No active editor")
        return editor

    def current_code(self) -> str:
        return self.current_editor().toPlainText()

    def current_lesson_info(self) -> dict[str, object]:
        lesson = self.lesson_manager.get(self.current_lesson_id)
        if lesson is None:
            return {}
        return {
            "lesson_id": lesson.lesson_id,
            "title": lesson.title,
            "summary": lesson.summary,
            "why_it_matters": lesson.why_it_matters,
            "tip": lesson.tip,
            "steps": lesson.steps,
            "checklist": lesson.checklist,
            "common_mistakes": lesson.common_mistakes,
            "example_code": lesson.example_code,
            "xp_reward": lesson.xp_reward,
            "unlocks": lesson.unlocks,
            "next_lesson": lesson.next_lesson,
        }

    def _current_stdin_text(self) -> str:
        lesson = self.lesson_manager.get(self.current_lesson_id)
        if lesson is None:
            return ""
        return str(lesson.validation_rules.get("stdin_text", ""))

    def new_editor_tab(self) -> None:
        if self.editor_tabs.count() >= 1 and not self.feature_enabled("multi_file_support"):
            self.status_bar.showMessage("Complete lessons to unlock multi-file support.", 4000)
            return

        editor = CodeEditor()
        editor.textChanged.connect(self._refresh_hint_state)
        index = self.editor_tabs.addTab(editor, f"lesson_{self.editor_tabs.count() + 1}.py")
        self.editor_tabs.setCurrentIndex(index)
        self._apply_feature_state()

    def close_editor_tab(self, index: int) -> None:
        if self.editor_tabs.count() == 1:
            return
        widget = self.editor_tabs.widget(index)
        self.editor_tabs.removeTab(index)
        widget.deleteLater()

    def open_file(self) -> None:
        if not self.feature_enabled("file_system_access"):
            self.status_bar.showMessage("File system access is still locked in learning mode.", 4000)
            return

        path, _ = QFileDialog.getOpenFileName(self, "Open Python File", str(APP_DIR), "Python Files (*.py);;All Files (*)")
        if not path:
            return

        file_path = Path(path)
        editor = self.current_editor()
        editor.setPlainText(file_path.read_text(encoding="utf-8"))
        self.editor_tabs.setTabText(self.editor_tabs.currentIndex(), file_path.name)
        self.status_bar.showMessage(f"Opened {file_path.name}", 4000)

    def save_file(self) -> None:
        if not self.feature_enabled("file_system_access"):
            self.status_bar.showMessage("File system access is still locked in learning mode.", 4000)
            return

        path, _ = QFileDialog.getSaveFileName(self, "Save Python File", str(APP_DIR / "lesson_work.py"), "Python Files (*.py)")
        if not path:
            return

        file_path = Path(path)
        file_path.write_text(self.current_code(), encoding="utf-8")
        self.editor_tabs.setTabText(self.editor_tabs.currentIndex(), file_path.name)
        self.status_bar.showMessage(f"Saved {file_path.name}", 4000)

    def run_code(self) -> ExecutionResult:
        result = self.runner.execute(self.current_code(), stdin_text=self._current_stdin_text())
        self._append_console(result)
        self._refresh_hint_state()
        return result

    def validate_current_lesson(self) -> ValidationResult:
        lesson = self.lesson_manager.get(self.current_lesson_id)
        if lesson is None:
            result = ValidationResult(success=False, messages=["No lesson is currently loaded."])
            self.status_bar.showMessage(result.messages[0], 4000)
            return result

        result = self.validator.validate(lesson, self.current_code())
        if result.success:
            already_completed = lesson.lesson_id in self.progress.completed_lessons()
            self.progress.mark_completed(lesson.lesson_id)
            unlocked = self.unlock_features(result.unlocked_features)
            xp_total = self.progress.xp()
            if not already_completed and result.xp_awarded:
                xp_total = self.progress.add_xp(result.xp_awarded)
            if unlocked:
                result.messages.append("Unlocked: " + ", ".join(unlocked))
            if not already_completed and result.xp_awarded:
                result.messages.append(f"XP total: {xp_total}")
            elif already_completed:
                result.messages.append("Lesson was already completed, so XP was not awarded again.")
            result.lesson_completed_now = not already_completed

        self._append_validation(result)
        self._apply_feature_state()
        self._update_progress_label()
        if result.success and result.lesson_completed_now:
            QTimer.singleShot(100, lambda: self._show_completion_dialog(lesson, result))
        return result

    def unlock_features(self, features: list[str]) -> list[str]:
        changed = self.progress.unlock_features(features)
        if changed:
            self._apply_feature_state()
            self.status_bar.showMessage("Unlocked: " + ", ".join(changed), 5000)
        return changed

    def go_to_next_lesson(self) -> bool:
        lesson = self.lesson_manager.get(self.current_lesson_id)
        if lesson is None or not lesson.next_lesson:
            return False
        if lesson.lesson_id not in self.progress.completed_lessons():
            self.status_bar.showMessage("Complete this lesson before moving to the next one.", 4000)
            return False
        self.current_lesson_id = lesson.next_lesson
        self.progress.set_current_lesson(self.current_lesson_id)
        self.current_editor().clear()
        self._load_current_lesson()
        return True

    def change_mode(self, mode: str) -> None:
        self.progress.set_mode(mode)
        self._apply_feature_state()
        self.status_bar.showMessage(f"Mode changed to {mode}.", 3000)

    def feature_enabled(self, feature_name: str) -> bool:
        if feature_name == "syntax_highlighting":
            return True
        if self.progress.current_mode() == "free":
            return FREE_MODE_FEATURES.get(feature_name, True)
        return self.progress.unlocked_features().get(feature_name, False)

    def reset_progress(self) -> None:
        first_lesson_id = self.lesson_manager.first_lesson_id()
        if not first_lesson_id:
            self.status_bar.showMessage("No lessons are available to reset to.", 4000)
            return
        self.progress.reset(first_lesson_id)
        self.current_lesson_id = first_lesson_id
        editor = self.current_editor()
        editor.clear()
        self.console.clear()
        self.mode_combo.setCurrentText(self.progress.current_mode())
        self._load_current_lesson()
        self._apply_feature_state()
        self.status_bar.showMessage("Progress reset. Back to the first lesson with XP cleared.", 5000)

    def _apply_feature_state(self) -> None:
        syntax_enabled = self.feature_enabled("syntax_highlighting")
        autocomplete_enabled = self.feature_enabled("autocomplete")
        multi_enabled = self.feature_enabled("multi_file_support")
        file_enabled = self.feature_enabled("file_system_access")
        error_hints = self.feature_enabled("error_hints")
        lesson = self.lesson_manager.get(self.current_lesson_id)
        completed = self.progress.completed_lessons()
        next_visible = bool(lesson and lesson.next_lesson and lesson.lesson_id in completed)

        for index in range(self.editor_tabs.count()):
            widget = self.editor_tabs.widget(index)
            if isinstance(widget, CodeEditor):
                widget.set_syntax_enabled(syntax_enabled)
                widget.set_autocomplete_enabled(autocomplete_enabled)

        self.editor_tabs.tabBar().setVisible(multi_enabled)
        self.new_tab_action.setVisible(multi_enabled)
        self.open_action.setVisible(file_enabled)
        self.save_action.setVisible(file_enabled)
        self.next_lesson_action.setVisible(next_visible)
        self.hint_label.setVisible(error_hints)
        self._refresh_hint_state()
        self._update_progress_label()

    def _refresh_hint_state(self) -> None:
        if not self.feature_enabled("error_hints"):
            self.hint_label.setText("Hints unlock after lessons.")
            return
        code = self.current_code().strip()
        if not code:
            self.hint_label.setText("Write some Python to get live hints.")
            return
        try:
            ast.parse(code)
            self.hint_label.setText("Syntax looks good.")
        except SyntaxError as error:
            self.hint_label.setText(f"Syntax issue on line {error.lineno}: {error.msg}")

    def _append_console(self, result: ExecutionResult) -> None:
        parts = ["$ python lesson.py"]
        if result.stdout.strip():
            parts.append(result.stdout.rstrip())
        if result.stderr.strip():
            parts.append(result.stderr.rstrip())
        if not result.stdout.strip() and not result.stderr.strip():
            parts.append("(no output)")
        self.console.setPlainText("\n\n".join(parts))
        self._scroll_console_to_bottom()

    def _append_validation(self, result: ValidationResult) -> None:
        existing = self.console.toPlainText().strip()
        notes = "\n".join(result.messages)
        merged = f"{existing}\n\n[Validation]\n{notes}" if existing else f"[Validation]\n{notes}"
        self.console.setPlainText(merged)
        self._scroll_console_to_bottom()

    def _load_initial_lesson(self) -> None:
        if not self.current_lesson_id:
            self.status_bar.showMessage("No lessons were found. Add a lesson folder inside /lessons.", 6000)
            return
        self._load_current_lesson()

    def _load_current_lesson(self) -> None:
        lesson = self.lesson_manager.get(self.current_lesson_id)
        if lesson is None:
            self.status_bar.showMessage(f"Lesson '{self.current_lesson_id}' could not be loaded.", 6000)
            return
        self.lesson_browser.setUrl(QUrl.fromLocalFile(str(lesson.html_path)))
        self.lesson_label.setText(f"Lesson: {lesson.title}")
        self._update_progress_label()

    def _update_progress_label(self) -> None:
        unlocked = sum(1 for value in self.progress.unlocked_features().values() if value)
        total = len(DEFAULT_FEATURES)
        self.progress_label.setText(
            f"XP {self.progress.xp()} | Level {self.progress.level()} | Features {unlocked}/{total}"
        )

    def _scroll_console_to_bottom(self) -> None:
        self.console.moveCursor(QTextCursor.End)
        scrollbar = self.console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _set_initial_splitter_sizes(self) -> None:
        if hasattr(self, "main_splitter"):
            self.main_splitter.setSizes([700, 520])
        if hasattr(self, "right_splitter"):
            self.right_splitter.setSizes([520, 240])

    def _show_completion_dialog(self, lesson: LessonDefinition, result: ValidationResult) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Lesson Complete")
        dialog.setModal(True)
        dialog.setStyleSheet(
            "QDialog { background: #0f172a; color: #eff6ff; }"
            "QLabel { color: #e0f2fe; }"
            "QPushButton { background: #1d4ed8; color: white; border-radius: 10px; padding: 10px 14px; }"
            "QPushButton:hover { background: #f97316; }"
        )

        layout = QVBoxLayout(dialog)
        title = QLabel(f"You completed {lesson.title}")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #fef3c7;")
        layout.addWidget(title)

        summary = QLabel(
            "Choose a reward option, then move to the next lesson when you're ready."
            if result.next_lesson else
            "You finished the final lesson. Save your reward files if you want."
        )
        summary.setWordWrap(True)
        layout.addWidget(summary)

        for message in result.messages:
            label = QLabel(f"- {message}")
            label.setWordWrap(True)
            layout.addWidget(label)

        button_row = QHBoxLayout()
        badge_button = QPushButton("Download Badge")
        certificate_button = QPushButton("Download Certificate")
        close_button = QPushButton("Stay Here")
        button_row.addWidget(badge_button)
        button_row.addWidget(certificate_button)
        if result.next_lesson:
            next_button = QPushButton("Next Lesson")
            button_row.addWidget(next_button)
            next_button.clicked.connect(lambda: (dialog.accept(), self.go_to_next_lesson()))
        button_row.addWidget(close_button)
        layout.addLayout(button_row)

        badge_button.clicked.connect(lambda: self._download_badge(lesson))
        certificate_button.clicked.connect(lambda: self._download_certificate(lesson))
        close_button.clicked.connect(dialog.reject)
        dialog.exec()

    def _download_badge(self, lesson: LessonDefinition) -> None:
        default_name = f"{lesson.lesson_id}_badge.png"
        path, _ = QFileDialog.getSaveFileName(self, "Save Badge", str(APP_DIR / default_name), "PNG Files (*.png)")
        if not path:
            return
        self._build_badge_image(lesson).save(path, "PNG")
        self.status_bar.showMessage(f"Saved badge to {Path(path).name}", 4000)

    def _download_certificate(self, lesson: LessonDefinition) -> None:
        learner_name, ok = QInputDialog.getText(self, "Certificate Name", "Name for the certificate:", text="PyQuest Learner")
        if not ok:
            return
        default_name = f"{lesson.lesson_id}_certificate.html"
        path, _ = QFileDialog.getSaveFileName(self, "Save Certificate", str(APP_DIR / default_name), "HTML Files (*.html)")
        if not path:
            return
        certificate_html = self._build_certificate_html(lesson, learner_name.strip() or "PyQuest Learner")
        Path(path).write_text(certificate_html, encoding="utf-8")
        self.status_bar.showMessage(f"Saved certificate to {Path(path).name}", 4000)

    def _build_badge_image(self, lesson: LessonDefinition) -> QImage:
        width = 1200
        height = 630
        image = QImage(width, height, QImage.Format_ARGB32)
        image.fill(QColor("#0f172a"))

        painter = QPainter(image)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.TextAntialiasing, True)

        gradient = QLinearGradient(0, 0, width, height)
        gradient.setColorAt(0.0, QColor("#0f172a"))
        gradient.setColorAt(0.5, QColor("#1d4ed8"))
        gradient.setColorAt(1.0, QColor("#0f766e"))
        painter.setBrush(QBrush(gradient))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(0, 0, width, height, 36, 36)

        painter.setBrush(QColor("#f97316"))
        painter.drawEllipse(78, 78, 184, 184)
        painter.setBrush(QColor("#22d3ee"))
        painter.drawEllipse(974, 54, 112, 112)

        painter.setPen(QPen(QColor("#fde68a")))
        painter.setFont(QFont("Segoe UI", 24, QFont.Bold))
        painter.drawText(80, 120, "PyQuest Studio Achievement")

        painter.setPen(QPen(QColor("#ffffff")))
        painter.setFont(QFont("Georgia", 34, QFont.Bold))
        painter.drawText(80, 190, 1040, 120, Qt.TextWordWrap, lesson.badge_title)

        painter.setPen(QPen(QColor("#dbeafe")))
        painter.setFont(QFont("Segoe UI", 18))
        painter.drawText(80, 330, "Completed in PyQuest Studio")

        painter.setPen(QPen(QColor("#a7f3d0")))
        painter.setFont(QFont("Segoe UI", 16, QFont.Bold))
        painter.drawText(80, 382, f"XP Reward: {lesson.xp_reward}")

        painter.setPen(QPen(QColor("#bfdbfe")))
        painter.setFont(QFont("Segoe UI", 15))
        painter.drawText(80, 430, "Share your progress and keep building.")

        painter.setBrush(QColor(15, 23, 42, 180))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(80, 490, 420, 72, 18, 18)

        painter.setPen(QPen(QColor("#ffffff")))
        painter.setFont(QFont("Segoe UI", 18, QFont.Bold))
        painter.drawText(110, 536, f"#{lesson.lesson_id}")

        painter.end()
        return image

    def _build_certificate_html(self, lesson: LessonDefinition, learner_name: str) -> str:
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Certificate - {lesson.title}</title>
  <style>
    body {{ margin: 0; font-family: Georgia, serif; background: #eef6ff; }}
    .sheet {{
      width: 1000px; margin: 40px auto; padding: 60px; background: white;
      border: 12px solid #1d4ed8; box-shadow: 0 16px 60px rgba(15, 23, 42, 0.16);
    }}
    h1 {{ font-size: 54px; text-align: center; color: #0f172a; margin-bottom: 10px; }}
    h2 {{ font-size: 30px; text-align: center; color: #0f766e; margin-top: 0; }}
    p {{ text-align: center; color: #334155; font-size: 22px; line-height: 1.6; }}
    .name {{ font-size: 48px; color: #1d4ed8; margin: 40px 0 20px; font-weight: bold; }}
    .lesson {{ font-size: 36px; color: #f97316; font-weight: bold; }}
    .footer {{ display: flex; justify-content: space-between; margin-top: 70px; font-size: 18px; }}
  </style>
</head>
<body>
  <div class="sheet">
    <h1>Certificate of Progress</h1>
    <h2>PyQuest Studio</h2>
    <p>This certificate is proudly presented to</p>
    <p class="name">{learner_name}</p>
    <p>for successfully completing the lesson</p>
    <p class="lesson">{lesson.title}</p>
    <p>{lesson.summary}</p>
    <div class="footer">
      <span>XP Earned: {lesson.xp_reward}</span>
      <span>Lesson ID: {lesson.lesson_id}</span>
    </div>
  </div>
</body>
</html>"""


def main() -> None:
    app = QApplication(sys.argv)
    window = LearningIDE()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

"""
(c) 2026 Poniek Labs and the Pyquest Team . All rights reserved."""