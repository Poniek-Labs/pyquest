let bridge = null;

function setStatus(message, tone = "neutral") {
  const status = document.getElementById("status");
  status.textContent = message;
  status.dataset.tone = tone;
}

function renderList(id, items, fallback) {
  const element = document.getElementById(id);
  const values = items && items.length ? items : [fallback];
  element.innerHTML = values.map((item) => `<li>${item}</li>`).join("");
}

function renderResult(result) {
  const box = document.getElementById("result");
  const lines = [];

  if (result.stdout) lines.push(result.stdout.trim());
  if (result.stderr) lines.push(result.stderr.trim());
  if (!lines.length) lines.push("(no output)");

  box.textContent = lines.join("\n\n");
}

function renderLesson(info) {
  document.getElementById("lesson-title").textContent = info.title || "Lesson";
  document.getElementById("lesson-summary").textContent = info.summary || "Work through the lesson in the editor.";
  document.getElementById("lesson-why").textContent = info.why_it_matters || "Each step builds practical Python habits.";
  document.getElementById("lesson-tip").textContent = info.tip || "Take it one step at a time.";
  document.getElementById("lesson-example").textContent = info.example_code || "# Example code will appear here";
  document.getElementById("xp-chip").textContent = `XP ${info.xp_reward || 0}`;
  document.getElementById("unlock-chip").textContent = info.unlocks?.length ? `Unlocks: ${info.unlocks.join(", ")}` : "Unlocks: lesson progress";
  document.getElementById("next-chip").textContent = info.next_lesson ? `Next: ${info.next_lesson}` : "Final lesson";

  renderList("lesson-steps", info.steps, "Follow the instructions in the editor.");
  renderList("lesson-checklist", info.checklist, "Complete the code task.");
  renderList("lesson-mistakes", info.common_mistakes, "Check spacing, spelling, and punctuation.");
}

function initializeBridge() {
  new QWebChannel(qt.webChannelTransport, (channel) => {
    bridge = channel.objects.ideBridge;
    bridge.getCurrentLessonInfo((info) => {
      renderLesson(info || {});
      setStatus("Lesson ready. Read the instructions, edit the starter code, then run and validate.");
      previewCode();
    });
  });
}

function runCode() {
  if (!bridge) return;
  bridge.runUserCode((result) => {
    renderResult(result || {});
    previewCode();
    setStatus("Code executed. Check the result panel and the IDE output box.");
  });
}

function validateCode() {
  if (!bridge) return;
  bridge.validateCode((result) => {
    const messages = result?.messages || [];
    document.getElementById("feedback").innerHTML = messages.map((msg) => `<li>${msg}</li>`).join("");
    previewCode();

    if (result?.success && result?.lesson_completed_now) {
      setStatus("Lesson complete. A reward menu opened in the app before you move on.", "success");
    } else if (result?.success) {
      setStatus("This lesson was already completed, but your code still passes.", "success");
    } else {
      setStatus("Almost there. Use the feedback below and try again.", "warning");
    }
  });
}

function previewCode() {
  if (!bridge) return;
  bridge.getUserCode((payload) => {
    document.getElementById("code-preview").textContent = payload?.code?.trim() || "(the editor is currently empty)";
  });
}

document.addEventListener("DOMContentLoaded", initializeBridge);
